window.addEventListener("load", function() {
	var canvas = document.getElementById("myCanvas");
	var ctx = canvas.getContext("2d");
	var ballRadius = 10;
	var ball_x = canvas.width/2;
	var ball_y = canvas.height-30;
	var ball_dx = 2;
	var ball_dy = -2;
	var paddleHeight = 10;
	var paddleWidth = 75;
	var paddleX = (canvas.width-paddleWidth)/2;
	var rightPressed = false;
	var leftPressed = false;
	// define the bricks
	var brickRowCount = 6;
	var brickColumnCount = 3;
	var brickWidth = 75;
	var brickHeight = 20;
	var brickOffsetTop = 30;
	var brickOffsetLeft = 30;
	//bricks interval
	var brickPadding_x = 10;
	var brickPadding_y = 8;
	
	var score = 0;
	var lives = 3;
	var speed = 1;

	var bricks = [];
	for(var c=0; c<brickColumnCount; c++) 
	{
	  bricks[c] = [];
	  for(var r=0; r<brickRowCount; r++) 
		bricks[c][r] = { x: 0, y: 0, status: 1 };
	}

	document.addEventListener("keydown", keyDownHandler, false);
	document.addEventListener("keyup", keyUpHandler, false);
	document.addEventListener("mousemove", mouseMoveHandler, false);

	function keyDownHandler(e) 
	{
	  if(e.keyCode == 39) 
		rightPressed = true;
	  else if(e.keyCode == 37) 
		leftPressed = true;
	}
	function keyUpHandler(e) 
	{
	  if(e.keyCode == 39) 
		rightPressed = false;
	  else if(e.keyCode == 37) 
		leftPressed = false;
	}
	function mouseMoveHandler(e) 
	{
	  var relativeX = e.clientX - canvas.offsetLeft;
	  if(relativeX > 0 && relativeX < canvas.width) 
		paddleX = relativeX - paddleWidth/2;
	}
	/*function keyPlusHandler(e) 
	{
	  if(e.keyCode == 39) 
		rightPressed = true;
	  else if(e.keyCode == 37) 
		leftPressed = true;
	}*/
	function brick_collisionDetection() 
	{
	  for(var c=0; c<brickColumnCount; c++) 
	  {
		for(var r=0; r<brickRowCount; r++) 
		{
		  var b = bricks[c][r];
		  if(b.status == 1) 
		  {
			if(ball_x > b.x && ball_x < b.x+brickWidth && ball_y > b.y && ball_y < b.y+brickHeight) 
			{
			  ball_dy = -ball_dy;
			  b.status = 0;
			  score++;
			  if(score == brickRowCount*brickColumnCount) 
			  {
				alert("YOU WIN, CONGRATULATIONS!");
				document.location.reload();
			  }
			}
		  }
		}
	  }
	}

	function drawBall() 
	{
	  ctx.beginPath();
	  ctx.arc(ball_x, ball_y, ballRadius, 0, Math.PI*2);
	  ctx.fillStyle = "red";
	  ctx.fill();
	  ctx.closePath();
	}
	function drawPaddle() 
	{
	  ctx.beginPath();
	  ctx.rect(paddleX, canvas.height-paddleHeight-10, paddleWidth, paddleHeight);
	  ctx.fillStyle = "black";
	  ctx.fill();
	  ctx.closePath();
	}
	function drawBricks() 
	{
	  for(var c=0; c<brickColumnCount; c++) 
	  {
		for(var r=0; r<brickRowCount; r++) 
		{
		  if(bricks[c][r].status == 1) 
		  {
			var brickX = (r*(brickWidth+brickPadding_x))+brickOffsetLeft;
			var brickY = (c*(brickHeight+brickPadding_y))+brickOffsetTop;
			bricks[c][r].x = brickX;
			bricks[c][r].y = brickY;
			ctx.beginPath();
			ctx.rect(brickX, brickY, brickWidth, brickHeight);
			ctx.fillStyle = "#0095DD";
			ctx.fill();
			ctx.closePath();
		  }
		}
	  }
	}
	function drawScore() 
	{
	  ctx.font = "20px Arial";
	  ctx.fillStyle = "#0095DD";
	  ctx.fillText("Score: "+score, 8, 20);
							  //start,length
	}
	function drawLives() 
	{
	  ctx.font = "16px Arial";
	  ctx.fillStyle = "#0095DD";
	  ctx.fillText("Lives: "+lives, canvas.width-65, 20);
	}
	
	function reborn_setting()
	{
		ball_x = canvas.width/2;
		ball_y = canvas.height-30;
		paddleX = (canvas.width-paddleWidth)/2;
	}
	
	function draw() 
	{
	  ctx.clearRect(0, 0, canvas.width, canvas.height);
	  drawBricks();
	  drawBall();
	  drawPaddle();
	  drawScore();
	  drawLives();
	  brick_collisionDetection();

	  if(ball_x + ball_dx > canvas.width-ballRadius || ball_x + ball_dx < ballRadius) 
		ball_dx = -ball_dx;
	
	  if(ball_y + ball_dy < ballRadius) 
		ball_dy = -ball_dy;
	 
	  else if(ball_y + ball_dy > canvas.height-ballRadius-10) 
	  {
		if(ball_x > paddleX && ball_x < paddleX + paddleWidth) 
		  ball_dy = -ball_dy;

		else 
		{
		  lives--;
		  if(!lives) 
		  {
			alert("GAME OVER");
			document.location.reload();
		  }
		  else 
		  {
			reborn_setting();
			ball_dx = 7-2*lives;
			ball_dy = -7+2*lives;
		  }
		}
	  }

	  if(rightPressed && paddleX < canvas.width-paddleWidth) 
		paddleX += 7;
	  
	  else if(leftPressed && paddleX > 0) 
		paddleX -= 7;
	  

	  ball_x += ball_dx;
	  ball_y += ball_dy;
	  requestAnimationFrame(draw);

	}

	draw();
	//setInterval(draw, 100);
});